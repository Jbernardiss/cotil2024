
data = input("> ")
print(type(data))