
m = float(input("Metros: "))
print(f"= {m*100}cm")
print(f"= {m*1000}mm")
