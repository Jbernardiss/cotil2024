
n1 = float(input("n1: "))
n2 = float(input("n2: "))

print(f"Média: {(n1 + n2) / 2}")
