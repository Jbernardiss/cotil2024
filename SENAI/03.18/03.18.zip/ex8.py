
dinheiro = float(input("Dinheiro(R$): "))
dolares = dinheiro / 5
print(f"U${dolares}")