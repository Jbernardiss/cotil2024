
n1 = int(input('n1: '))
n2 = int(input('n2: '))

print(f"n1 + n2: {n1 + n2}")