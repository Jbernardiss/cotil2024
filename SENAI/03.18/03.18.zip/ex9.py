
h = float(input("Altura Parede: "))
l = float(input("Largura Parede: "))

areaParede = h * l

print(f"São precisos {areaParede/2}L de tinta para pintar a parede")
