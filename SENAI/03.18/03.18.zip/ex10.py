preco = float(input("Preço: "))
print(f"5% de desconto: R${preco * 0.95}")