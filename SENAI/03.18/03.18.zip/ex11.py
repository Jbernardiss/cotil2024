sal = float(input("Salário: "))

print(f"Aumento de 15%: {sal * 1.15}")