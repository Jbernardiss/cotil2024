
n = int(input("Número: "))

for i in range(11):
    print(f"{n} x {i} = {n * i}")