
n = int(input("n: "))
print(f"seq: {n-1}, {n}, {n+1}")