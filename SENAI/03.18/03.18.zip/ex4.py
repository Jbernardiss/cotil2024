
n = int(input("n: "))

print(f"Dobro: {n*2}")
print(f"Triplo: {n*3}")
print(f"Quadrado: {n*n}")